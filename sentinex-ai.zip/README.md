# Sentinex AI

An AI-powered sentiment-based trading bot.
