# Core trading logic
